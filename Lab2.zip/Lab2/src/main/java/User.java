import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/user/update")
public class User extends HttpServlet {
	String fullname; 
	boolean gender; 
	String country; 
	
	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public boolean isGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User bean = new User(); 
		bean.setFullname("Nguyễn Văn Tèo"); 
		bean.setGender(true); 
		bean.setCountry("VN");
		
		req.setAttribute("user", bean);
		req.setAttribute("Editabled", true);
		req.getRequestDispatcher("/form.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fullname = req.getParameter("Fullname");
		System.out.println(fullname);
		req.getRequestDispatcher("/form.jsp").forward(req, resp);
	}
}
